from flask import Flask, render_template, request, redirect, url_for, session
app = Flask(__name__)
app.secret_key = 'aravind krishnaswamy'

from user_model import User

@app.route('/create')
def display_create_page():
    return render_template('create.html')

@app.route('/create', methods=['POST'])
def create_user():
    # if request.method == 'POST':
    this_user = User.create_user(request.form)
    return redirect('/read_all')
    # else:
    #     this_user = User.create_user(request.form)
    #     return render_template('read_all.html', user = this_user)

@app.route('/read_all')
def display_read_page():
    user_list = User.select_all_users()
    return render_template('read_all.html', users = user_list)

@app.route('/read_all', methods = ['POST'])
def read_all():
    # if request.method == 'GET':
    all_users = User.select_all_users()
    return redirect('/create', all_users = all_users)
    # else:

@app.route('/read_one/<int:id>')
def display_read_one_page(id):
    this_user = User.select_one_user(id)
    return render_template('read_one.html', user = this_user)

@app.route('/read_one/<int:id>', methods=['POST'])
def read_one(id):
    User.select_one_user(id)
    return redirect('/read_one/<int:id>')

@app.route('/update/<int:id>')
def display_update_user_page(id):
    update_this_user = User.select_one_user(id)
    return render_template('edit.html', user = update_this_user)

@app.route('/update/<int:id>', methods=['POST'])
def update_user(id):
    data = {
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email'],
        'id': id
    }
    User.update_user(data)
    return redirect(f'/read_one/{id}')

@app.route('/delete/<int:id>')
def delete_user(id):
    User.delete_user(id)
    return redirect('/read_all')


# @app.route('/')
# def index():
#     # calling the get_all method from the friends.py
#     all_friends=Friend.get_all()
#     # passing all friends to our template so we can display them there
#     return render_template("index.html",friends=all_friends)
# @app.route('/friend/show/<int:friend_id>')
# def show(friend_id):
#     # calling the get_one method and supplying it with the id of the friend we want to get
#     friend=Friend.get_one(friend_id)
#     return render_template("show_friend.html",friend=friend)

if __name__=='__main__':
    app.run(debug=True)