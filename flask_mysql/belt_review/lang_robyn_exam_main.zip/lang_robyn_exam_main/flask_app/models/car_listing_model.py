from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user_model
from flask import flash
import pprint
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


db = 'exam1_car_dealz'

#the many
class Car_listing:
    def __init__(self, data):
        self.id = data['id']
        self.price = data['price']
        self.model = data['model']
        self.make = data['make']
        self.year = data['year']
        self.description = data['description']
        self.user_id = data['user_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user = None
        # updated

    @classmethod
    def create_car_listing(cls, data):
        query = '''
        INSERT INTO car_listings (price, model, make, year, description, user_id) VALUES (%(price)s, %(model)s, %(make)s, %(year)s, %(description)s, %(user_id)s)
        ;'''
        return connectToMySQL(db).query_db(query, data)
    # this works
    # updated

    # takes data dictionary from request.form
    # validates data
    # return id? or False if the validations fail

    @classmethod
    def get_all_car_listings_with_user(cls):
        query = '''
        SELECT * FROM car_listings LEFT JOIN users ON car_listings.user_id = users.id
        ;'''
        results = connectToMySQL(db).query_db(query)
        car_listings = []
        for db_row in results:
            car_listing_instance = cls(db_row)
            user_data = {
                'id': db_row['users.id'],
                'first_name': db_row['first_name'],
                'last_name': db_row['last_name'],
                'email': db_row['email'],
                'password': None,
                'created_at': db_row['users.created_at'],
                'updated_at': db_row['users.updated_at'],
            }
            car_listing_instance.user = user_model.User(user_data)
            car_listings.append(car_listing_instance)
        pprint.pprint(results, sort_dicts = False)
        return car_listings
    # this works
    # updated

    # get all recipes, and the user info for the creators
    # make a list to hold recipe objects to return
    # return the list of class instances
    # whenever we are sending back data, we want it to be in the form of a class instance
    # a class instance is a way to keep all of your data organized, and attributes can be added on

    @classmethod
    def get_car_listing_by_id(cls, data):
        query = '''
        SELECT * from car_listings LEFT JOIN users on car_listings.user_id = users.id WHERE car_listings.id = %(id)s
        ;'''
        car_listing_id = {
            'id': data
        }
        result = connectToMySQL(db).query_db(query, car_listing_id)
        pprint.pprint(result, sort_dicts=False)
        car_listing_instance = cls(result[0])
        for car_listing in result:
            user_data = {
                'id': car_listing['users.id'],
                'first_name': car_listing['first_name'],
                'last_name': car_listing['last_name'],
                'email': car_listing['email'],
                'password': None,
                'created_at': car_listing['users.created_at'],
                'updated_at': car_listing['users.updated_at'],
            }
            user_instance = user_model.User(user_data)
            car_listing_instance.user = user_instance
        return car_listing_instance
    # this works
    # updated

    # get recipe data with user data who created it
    # make a recipe object from the data
    # associate user with recipe
    # return recipe


    @classmethod
    def edit_car_listing(cls, data):
        query = '''
        UPDATE car_listings SET price = %(price)s, model = %(model)s, make = %(make)s, year = %(year)s, description = %(description)s WHERE id = %(id)s
        ;'''
        return connectToMySQL(db).query_db(query, data)
    # this works
    # updated

    # takes data dictionary from request.form


    @classmethod
    def delete_car_listing(cls, car_listing_id):
        query = '''
        DELETE FROM car_listings WHERE id = %(id)s
        ;'''
        data = {'id': car_listing_id}
        return connectToMySQL(db).query_db(query, data)
    # this works
    # updated

    # delete recipe using the id