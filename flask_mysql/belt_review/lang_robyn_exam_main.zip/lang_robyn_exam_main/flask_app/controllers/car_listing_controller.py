from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models import user_model
from flask_app.models import car_listing_model
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('You need to log in to access this page.', 'not_logged_in')
        return redirect('/')
    data = {
        'id': session['user_id']
    }
    car_listings = car_listing_model.Car_listing.get_all_car_listings_with_user()

    return render_template('2_dashboard.html', user = user_model.User.get_user_by_id(data), car_listings = car_listings)
# this works

@app.route('/new')
def display_create_car_listing_form():
    return render_template('3_create_new_car_listing.html')
# this works

@app.route('/new', methods = ['POST'])
def create_car_listing():
    if not user_model.User.validate_car_listing(request.form):
        return redirect('/new')
    data = {
            'price': request.form['price'],
            'model': request.form['model'],
            'make': request.form['make'],
            'year': request.form['year'],
            'description': request.form['description'],
            'user_id': session['user_id'],
        }
    car_listing_model.Car_listing.create_car_listing(data)
    return redirect('/dashboard')
# this works

@app.route('/show/<int:id>')
def display_one_car_with_seller(id):
    car_listing = car_listing_model.Car_listing.get_car_listing_by_id(id)
    return render_template('4_display_one_car_listing.html', car_listing = car_listing)

@app.route('/edit/<int:id>')
def display_edit_car_listing_page(id):
    car_listing = car_listing_model.Car_listing.get_car_listing_by_id(id)
    return render_template('5_edit_one_car_listing.html', car_listing = car_listing)

@app.route('/edit/<int:id>', methods = ['POST'])
def edit_one_car_listing(id):
    if not user_model.User.validate_car_listing(request.form):
        return redirect(f'/edit/{id}')
    data = {
        'id': id,
        'price': request.form['price'],
        'model': request.form['model'],
        'make': request.form['make'],
        'year': request.form['year'],
        'description': request.form['description'],
    }
    car_listing_model.Car_listing.edit_car_listing(data)
    return redirect('/dashboard')

@app.route('/delete/<int:id>')
def delete_car_listing(id):
    car_listing_model.Car_listing.delete_car_listing(id)
    return redirect('/dashboard')