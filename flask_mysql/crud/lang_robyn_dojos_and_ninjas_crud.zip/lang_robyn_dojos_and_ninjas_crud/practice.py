# - rotate String
#         Create a standalone function that accepts a string and an integer, and rotates the characters in the string to the right by that amount. ex: given ("boris godunov",5) return "dunovBoris Go"

def rotate_string(string, integer):
    #look at the end, start from the end counting backwards integer number of times


# bad characters
#         - write a function that when given two strings, the second string contains characters that must be romved from the first. return the resultant string
# print(chicken, ikn) ==> chce

def bad_characters(string1, string2):
    #whatever letters match have to be removed from the first string
    result = ""
    # list = []
    for i in range(len(string2)):
        if i == 
    return result

print(bad_characters('chicken', 'ikn'))

# - create a function that given a string, returns the integer made from the string's digits. Given "0s1a3y5w7h9a2t4", the function should return the number 1357924

# def blah(num):
#     open_str = ""
#     lst = []
#     for i in range(len(num)):
#         sum = num[i] + num(i + 1)
#         #sum = num[i] + num(i + 1)
#         if sum ==  % int
#             return sum
# print(blah("0s1a3y5w7h9a2t4"))